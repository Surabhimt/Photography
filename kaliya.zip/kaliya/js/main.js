


// mobile menu
$('.navicon').on('click', function(e) {
     $('body').toggleClass('open-menu');
    e.preventDefault();
   
});



function bindMenuHover(){

     var w = $(window).width();
        if(w > 960) {
       jQuery("nav li").hover(function (){
        
        $(this).children(".sub-menu").stop(true,true).slideDown("slow");
        
        },function (){
        
        $(this).children(".sub-menu").slideUp("slow");
        
        }
        );

     }else{
           jQuery("nav li").unbind('mouseenter mouseleave')
     }
     
  }

$(document).ready(function () {
    bindMenuHover();
     jQuery("nav .icon").click(function(e){
            $(this).toggleClass("open");
            $(this).parent('li').children(".sub-menu").slideToggle();
            e.preventDefault();

       });
});

$( window ).resize(function() {
bindMenuHover();

});